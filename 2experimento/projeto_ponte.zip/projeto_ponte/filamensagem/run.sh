clear
gcc -o ponte ponte.c mensagem.c engine.c -I.
./ponte
