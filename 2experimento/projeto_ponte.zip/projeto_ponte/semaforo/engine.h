#ifndef ENGINE_H
#define ENGINE_H

extern void cabecalho_da_tabela();
extern void printCrianca(int id, int num_travessias, char lado[9],	
					int tempoDecisao, char estado[13]);

#endif
