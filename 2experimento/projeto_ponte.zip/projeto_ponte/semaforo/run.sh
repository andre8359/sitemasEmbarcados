clear
gcc -o ponte travessiaponte.c semaforo.c engine.c -I.
./ponte
