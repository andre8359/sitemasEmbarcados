#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>


int imagem[1000][1000];
//int imagem_filtrada[1000][1000];
int mediana;
int max=0;



int calcula_mediana(int v[], int tam){
    
    int flag, i,k;
    int medi, t0;
	printf("\n");
	//printf("tamanh0:%d\n",tam);
    for(k=0;k<tam;k++){
	printf("v[%d]: %d\t",k,v[k]);
	}


    do
    {
        flag=0;
        for(i=1;i<tam;i++)
        {
            if(v[i-1]>v[i])
            {
                t0=v[i-1];
                v[i-1]=v[i];
                v[i]=t0;
                flag=1;
            }
        }
    }
    while (flag==1);

	printf("\n");
	for(k=0;k<tam;k++){
		printf("v_o[%d]: %d\t",k,v[k]);
	}
	
    medi=v[(tam/2)];
	printf("mediana: %d\n",medi);
	
	if(medi>max){
		max=medi;}
    return medi;
}




struct variaveis
{
	int f;
	int l;
	int c;
	int length;

};


void* calcula_pixel (void* parameters)
{
	struct variaveis* p = (struct variaveis*) parameters;

 	int i,med,k;
    	int vetor[p->f], t1;
    

	if (((p->f)%2)!=0)
	{	
		

		if ((p->c)<((p->f)/2))
		{	//printf("filtro: %d\tcoluna:%d\n",(p->f)/2,p->c);
			k=2*(p->c)+1;
			//printf("%d\n",k);
			for (i=0;i<k;i++)
			{
				vetor[i]=imagem[p->l][i];
			}
		med=calcula_mediana(vetor,k);
		//imagem_filtrada[p->l][p->c]=med;
		mediana=med;
		//printf("mediana retornada borda esquerda: \n",med);
		}	
    
		if ((p->c)>((p->length)-((p->f)/2)-1))
		{	//printf("filtro: %d\tcoluna:%d\n",(p->f)/2,p->c);
			k=(((p->length)-(p->c))*2+1);
			t1=(p->length)-(p->c)-1;
			for (i=0;i<k;i++)
			{
				vetor[i]=imagem[p->l][(p->c)-t1+i];
			}
		med=calcula_mediana(vetor,k);
		//imagem_filtrada[p->l][p->c]=med;
		mediana=med;
		//printf("mediana retornada borda direita: \n",med);
		}
		if(	(p->c)>=((p->f)/2)	&	(p->c)<=((p->length)-((p->f)/2)-1) ){	
			//printf("Meio:P_%d_%d\n",p->l,p->c);
			for (i=0;i<(p->f);i++)
			{
				vetor[i]=imagem[p->l][(p->c)-(p->f)/2+i];
			}
		med=calcula_mediana(vetor,p->f);
		//imagem_filtrada[p->l][p->c]=med;
		mediana=med;
		//printf("mediana retornada centro: \n",med);
		}
        }
	else{
		printf("filtro par");
	}	    
    	return 0;
}






int main (int argc, char* argv[])

{
	int largura;
	int altura;
	int filtro;
	
	largura = atoi(argv[1]);
	altura = atoi(argv[2]);
	filtro = atoi(argv[3]);

	int linha;
	int coluna;
	unsigned char pixel;
	int i=0,k=0;
	int id;


	FILE *FileID;
	FileID=fopen("img3_512_512.y","rb");
	

	FILE *FileID2;
	FileID2=fopen("foto.pgm","a");


	fprintf(FileID2,"P5 %d %d 255\n", largura,altura);

	for(linha=0;linha<altura;linha++)
	{
		for(coluna=0;coluna<largura;coluna++)
		{
			fscanf(FileID,"%c",&pixel);
			fwrite(&pixel, sizeof(char), 1, FileID2);
			imagem[linha][coluna]=pixel;
		}
	}

	fclose(FileID);
	fclose(FileID2);

	pthread_t thread1_id[linha*coluna];
	struct variaveis thread1_args[linha*coluna];

	FILE *FileID3;
	FileID3=fopen("img3filtrada.pgm","a");
	fprintf(FileID3,"P5 %d %d 255\n", largura,altura);


	for(linha=0;linha<altura;linha++)
	{
		for(coluna=0;coluna<largura;coluna++)
		{
		
			thread1_args[i].l=linha;
			thread1_args[i].c=coluna;
			thread1_args[i].f=filtro;
			thread1_args[i].length=largura;

			id=pthread_create (&thread1_id[i], NULL, &calcula_pixel, &thread1_args[i]);

			if(id){
				printf("Erro na criação da thread1_id[%d]\n",(linha*largura+coluna));
				printf("Erro : %d\n",id);
				exit(1);
			}
	
			pthread_join(thread1_id[i], NULL);
			fwrite(&mediana, sizeof(char), 1, FileID3);
		}
	}
		fclose(FileID3);
/*
	FILE *FileID3;
	FileID3=fopen("img3filtrada.pgm","a");
	fprintf(FileID3,"P5 %d %d %d\n", largura,altura,max);
	linha=0;
	coluna=0;

	
	for(linha=0;linha<altura;linha++)
	{
		for(coluna=0;coluna<largura;coluna++)
		{
			fwrite(&imagem_filtrada[linha][coluna], sizeof(char), 1, FileID3);
		}
	}
	fclose(FileID3);
*/
	/*while(!feof(FileID3)&(linha<altura)){
			fwrite(&imagem_filtrada[linha][coluna], sizeof(char), 1, FileID3);
			coluna++;
			if (coluna==largura-1){
				linha++;
				coluna=0;}	
	}*/	

	printf("\n\n valor maximo: %d",max);
	return 0;
}
